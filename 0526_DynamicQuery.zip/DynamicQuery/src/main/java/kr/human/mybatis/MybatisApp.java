package kr.human.mybatis;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisApp {
	// 1. 정적 멤버로 팩토리 변수 선언하기
	private static SqlSessionFactory sqlSessionFactory;
	
	// 2. 정적필드를 초기화하는 정적 초기화 블록만들기
	static {
		String resource = "mybatis-config.xml";
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// 3. 외부에서 객체를 얻도록 하는 메서드를 만들자
	public static SqlSessionFactory getSqlSessionFactory() {
		return sqlSessionFactory;
	}
}
